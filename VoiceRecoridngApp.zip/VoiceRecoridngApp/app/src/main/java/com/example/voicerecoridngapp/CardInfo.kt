package com.example.voicerecoridngapp

data class CardInfo(
    var title : String,
    var priority : String
)
