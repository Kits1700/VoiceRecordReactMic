package com.example.voicerecoridngapp

import android.content.Context
import android.os.Parcel
import android.os.Parcelable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ViewHolder

class AdapterRecord() : RecyclerView.Adapter<AdapterRecord.HolderRecord>() {
    private var context: Context?=null
    private var recordList:ArrayList<ModelRecord>?=null


    constructor(context: Context?, recordList: ArrayList<ModelRecord>?) : this() {
        this.context = context
        this.recordList = recordList
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HolderRecord {
        return HolderRecord(
            LayoutInflater.from(context).inflate(R.layout.row_record,parent,false)
        )

    }

    override fun onBindViewHolder(holder: HolderRecord, position: Int) {
        val model = recordList!!.get(position)
        val id = model.id
        val fname = model.fname
        val lname = model.lname
        val age = model.age
        val dob = model.dob
        val gender = model.gender

        holder.firstnameTV.text = fname
        holder.lastnameTV.text = lname
        holder.ageTV.text = age
        holder.dobTV.text = dob
        holder.genderTV.text = gender


    }

    override fun getItemCount(): Int {
        return recordList!!.size
    }
    inner class HolderRecord(itemView: View): RecyclerView.ViewHolder(itemView) {

        var firstnameTV:TextView = itemView.findViewById(R.id.firstnameTV)
        var lastnameTV:TextView = itemView.findViewById(R.id.lastnameTV)
        var ageTV:TextView = itemView.findViewById(R.id.ageTV)
        var dobTV:TextView = itemView.findViewById(R.id.dobTV)
        var genderTV:TextView = itemView.findViewById(R.id.genderTV)
        var morebtn:ImageButton = itemView.findViewById(R.id.morebtn)

    }




}