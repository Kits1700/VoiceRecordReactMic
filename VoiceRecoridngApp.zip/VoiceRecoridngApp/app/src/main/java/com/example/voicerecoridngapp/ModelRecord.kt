package com.example.voicerecoridngapp

class ModelRecord(
    var id:String,
    var fname:String,
    var lname:String,
    var age:String,
    var dob:String,
    var gender:String
)
