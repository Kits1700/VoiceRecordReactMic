package com.example.voicerecoridngapp.DTO

class ToDo {
    var id : Long = -1
    var name = ""
    var createdAt = ""
}