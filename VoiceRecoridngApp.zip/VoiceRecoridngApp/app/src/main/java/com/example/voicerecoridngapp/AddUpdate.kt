package com.example.voicerecoridngapp
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_add_update.*
import kotlinx.android.synthetic.main.activity_assign.*

class AddUpdate : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_update)
        btnSave.setOnClickListener{

            // below we have created
            // a new DBHelper class,
            // and passed context to it
            val db = MyDBHelper(this,null)

            // creating variables for values
            // in name and age edit texts
            val fname = FName.text.toString()
            val lname = LName.text.toString()
            val age = Age.text.toString()
            val dob = Date.text.toString()
            val gender = Gender.text.toString()
            //val gender = enterGender.text.toString()

            // calling method to add
            // name to our database
            db.addName(fname,lname, age,gender,dob)

            // Toast to message on the screen
            Toast.makeText(this, lname + "added to database", Toast.LENGTH_LONG).show()

            // at last, clearing edit texts
            FName.text.clear()
            LName.text.clear()
            Age.text.clear()
            Date.text.clear()
            Gender.text.clear()


            intent= Intent(this, AssignActivity::class.java)
            startActivity(intent)

            Toast.makeText(this,"Back to recs page",Toast.LENGTH_LONG).show()
            //enterGender.text.clear()
        }


        }
    }




