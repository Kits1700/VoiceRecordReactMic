package com.example.voicerecoridngapp

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.voicerecoridngapp.DTO.ToDo

class DBHandler(val context: Context) : SQLiteOpenHelper(context,DB_NAME,null,DB_VERSION) {
    override fun onCreate(p0: SQLiteDatabase) {
        val createToDoTable = " CREATE TABLE ToDo (" +
                "$COL_ID integer PRIMARY KEY AUTOINCREMENT," +
                "$COL_CREATED_AT datetime DEFAULT CURRENT_TIMESTAMP," +
                "$COL_NAME varchar);"
        p0.execSQL(createToDoTable)
    }

    override fun onUpgrade(p0: SQLiteDatabase, p1: Int, p2: Int) {

    }

    fun addToDO(toDo: ToDo) : Boolean {
        val db: SQLiteDatabase = writableDatabase
        val cv = ContentValues()
        cv.put(COL_NAME, toDo.name)
        val result: Long = db.insert(TABLE_NAME, null, cv)
        return result != (-1).toLong()
    }

    fun getToDo() : MutableList<ToDo>{

        val result : MutableList<ToDo> = ArrayList ()
        val db : SQLiteDatabase = readableDatabase
        val queryResult = db.rawQuery("SELECT * from $TABLE_NAME",null)

        if(queryResult.moveToFirst()){
            do {
                val toDo = ToDo()
                toDo.id = queryResult.getLong(queryResult.getColumnIndex(COL_ID))
                toDo.name = queryResult.getString(queryResult.getColumnIndex(COL_NAME))
                result.add(toDo)



            }while (queryResult.moveToNext())

        }

        queryResult.close()
        return result
    }

}