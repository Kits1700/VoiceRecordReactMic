package com.example.voicerecoridngapp

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.voicerecoridngapp.DTO.ToDo


class MyDBHelper(context: Context, factory: SQLiteDatabase.CursorFactory?) :
    SQLiteOpenHelper(context, DATABASE_NAME, factory, DATABASE_VERSION) {

    // below is the method for creating a database by a sqlite query
    override fun onCreate(db: SQLiteDatabase) {
        // below is a sqlite query, where column names
        // along with their data types is given
        val query = ("CREATE TABLE " + TABLE_NAME + " ("
                + ID_COL + " INTEGER PRIMARY KEY, " +
                FIRST_NAME_COl + " TEXT," + LAST_NAME_COl + " TEXT,"+
                AGE_COL + " TEXT," + GENDER_COL +" TEXT,"+ DOB_COL+"TEXT "+")")

        // we are calling sqlite
        // method for executing our query
        db.execSQL(query)
    }

    override fun onUpgrade(db: SQLiteDatabase, p1: Int, p2: Int) {
        // this method is to check if table already exists
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME)
        onCreate(db)
    }

    // This method is for adding data in our database
    fun addName(fname : String,lname:String, age : String,dob:String,gender:String){

        // below we are creating
        // a content values variable
        val values = ContentValues()

        // we are inserting our values
        // in the form of key-value pair
        values.put(FIRST_NAME_COl, fname)
        values.put(LAST_NAME_COl,lname)
        values.put(AGE_COL, age)
        values.put(DOB_COL,dob)
        values.put(GENDER_COL,gender)
        //values.put(GENDER_COL,gender)

        // here we are creating a
        // writable variable of
        // our database as we want to
        // insert value in our database
        val db = this.writableDatabase

        // all values are inserted into database
        db.insert(TABLE_NAME, null, values)

        // at last we are
        // closing our database
        db.close()
    }

    // below method is to get
    // all data from our database

    fun getRec() : MutableList<ToDo>{
        val result : MutableList<ToDo> = ArrayList ()
        val db:SQLiteDatabase = readableDatabase
        val queryResult: Cursor = db.rawQuery("SELECT $FIRST_NAME_COl from ${TABLE_NAME}",null)
        if(queryResult.moveToFirst()){
            do {
                val toDo = ToDo()
                if (queryResult.moveToFirst()){
                    do{
                        val toDo = ToDo()
                        //toDo.id = queryResult.getLong(queryResult.getColumnIndexOrThrow(ID_COL))
                        toDo.name = queryResult.getString(queryResult.getColumnIndexOrThrow(FIRST_NAME_COl))

                        result.add(toDo)

                    }while (queryResult.moveToNext())
                }


            }while (queryResult.moveToNext())
        }
        queryResult.close()
        return result

    }

    companion object{
        // here we have defined variables for our database

        // below is variable for database name
        private val DATABASE_NAME = "TESTDB1"

        // below is the variable for database version
        private val DATABASE_VERSION = 1

        // below is the variable for table name
        val TABLE_NAME = "testdb_table"

        // below is the variable for id column
        val ID_COL = "id"

        // below is the variable for name column
        val FIRST_NAME_COl = "fname"
        val LAST_NAME_COl = "lname"

        // below is the variable for age column
        val AGE_COL = "age"

        val DOB_COL = "dob"

        // below is the variable for gender column
        val GENDER_COL = "gender"
    }
}