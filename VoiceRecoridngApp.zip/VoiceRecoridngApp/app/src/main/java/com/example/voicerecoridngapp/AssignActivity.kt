package com.example.voicerecoridngapp

import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.example.voicerecoridngapp.DTO.ToDo

import com.example.voicerecoridngapp.R.*
import com.example.voicerecoridngapp.R.id.firstnameTV
import kotlinx.android.synthetic.main.activity_assign.*
import kotlinx.android.synthetic.main.rv_child_dashboard.*
import kotlinx.android.synthetic.main.activity_main.*

import kotlinx.android.synthetic.main.row_record.view.*


class AssignActivity : AppCompatActivity() {
    lateinit var dbHandler: DBHandler

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(layout.activity_assign)
        add.setOnClickListener {
            val intent = Intent(this, CreateCard::class.java)
            startActivity(intent)

        }
        deleteAll.setOnClickListener {

            DataObject.deleteAll()
            setRecycler()

        }
        recycler_view.adapter = Adapter(DataObject.getAllData())
        recycler_view.layoutManager = LinearLayoutManager(this)
    }

    fun setRecycler() {
        recycler_view.adapter = Adapter(DataObject.getAllData())
        recycler_view.layoutManager = LinearLayoutManager(this)
    }
}
//        dbHandler = DBHandler(this)
//        rv_dashboard.layoutManager = LinearLayoutManager(this)
//        addbtn.setOnClickListener{
//            val intent = Intent(this, AddUpdate::class.java)
//            //intent.putExtra("key", value)
//            startActivity(intent)
////            val dialog = AlertDialog.Builder(this)
////            val view = layoutInflater.inflate(R.layout.dialog_dashboard,null)
////            val toDoName = view.findViewById<EditText>(R.id.tv_todo)
////            dialog.setView(view)
//
////            dialog.setPositiveButton("Add") { _: DialogInterface, _: Int ->
////                if(toDoName.text.isNotEmpty())
////                {
////                    val toDo = ToDo()
////                    toDo.name = toDoName.text.toString()
////                    dbHandler.addToDO(toDo)
////                    refreshList()
////                }
//
//            }
////            dialog.setNegativeButton("Cancel") { _: DialogInterface, _: Int ->
////
////            }
////            dialog.show()






//    override fun onResume() {
//        refreshList()
//        super.onResume()
//    }
//    private fun refreshList(){
//        rv_dashboard.adapter = DashboardAdapter(this,dbHandler.getToDo())
//    }

//    class DashboardAdapter(val context: Context, private val list: MutableList<ToDo>) : RecyclerView.Adapter<DashboardAdapter.ViewHolder>(){
//
//
//        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
//            return ViewHolder(LayoutInflater.from(context).inflate(R.layout.rv_child_dashboard,parent,false))
//        }
//
//        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
//             holder.toDoName.text = list[position].name
//
//        }
//
//        override fun getItemCount(): Int {
//            return list.size
//        }
//        class ViewHolder(v : View) : RecyclerView.ViewHolder(v){
//            val toDoName : TextView = v.findViewById(R.id.tv_todo_name)
//
//        }
//    }
//}
//
//




